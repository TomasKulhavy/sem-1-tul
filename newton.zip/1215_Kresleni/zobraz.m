function zobraz(X)
    x=X(1,1:end);
    y=X(2,1:end);
    plot(x,y)
    axis equal
end
