function X=domecek
    X=[0,1,0,1,0,0,0.5,1,1; 0,0,1,1,0,1,1.5,1,0];
end