function X=jednanula
    X=[0,1,0.9,1,0.9; 0,0,0.1,0,-0.1];
end