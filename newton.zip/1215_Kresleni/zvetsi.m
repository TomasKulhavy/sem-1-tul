function Y=zvetsi(X,k)
    Y=k*X;
end
