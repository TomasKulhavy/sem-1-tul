function Y=vektorrofi(ro,fi)
    Y=otoc(zvetsi(jednanula,ro),fi);
end