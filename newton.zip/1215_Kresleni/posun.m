function Y=posun(X,x0) % x0 = sloupcový vektor
    Y=X+x0;
end
