x=[0,1,0.9,1,0.9];
y=[0,0,0.1,0,-0.1];
plot(x,y)
axis equal