function y=funkce(x)
    %y=x^2-4;
    y=x^2+log10(x)-7;
end